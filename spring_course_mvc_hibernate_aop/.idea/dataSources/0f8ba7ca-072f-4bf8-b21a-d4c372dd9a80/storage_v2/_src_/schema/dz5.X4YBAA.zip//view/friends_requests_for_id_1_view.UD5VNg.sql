create definer = root@localhost view friends_requests_for_id_1_view as
select `f`.`initiator_user_id` AS `initiator_user_id`, `f`.`target_user_id` AS `target_user_id`
from `dz5`.`friend_requests` `f`
where ((`f`.`status` = 'approved') and ((`f`.`target_user_id` = 1) or (`f`.`initiator_user_id` = 1)));

