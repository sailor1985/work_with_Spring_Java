create definer = root@localhost view finally_view as
select concat(`u`.`firstname`, ' ', `u`.`lastname`) AS `Друзья друзей пользователя Reuben Nienow (id = 1)`
from (`dz5`.`users` `u` join `dz5`.`friends_of_friends` `f` on ((`dz5`.`f`.`target_user_id` = `u`.`id`)));

