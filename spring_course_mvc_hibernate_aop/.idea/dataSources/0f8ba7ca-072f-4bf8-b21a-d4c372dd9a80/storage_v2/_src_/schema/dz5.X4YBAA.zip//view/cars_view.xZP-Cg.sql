create definer = root@localhost view cars_view as
select `dz5`.`cars`.`id` AS `id`, `dz5`.`cars`.`name` AS `name`
from `dz5`.`cars`
where (`dz5`.`cars`.`name` in ('Skoda', 'Audi'));

