create definer = root@localhost view friends_1_ids as
select `dz5`.`f`.`initiator_user_id` AS `f_ids`
from `dz5`.`friends_requests_for_id_1_view` `f`
where (`dz5`.`f`.`initiator_user_id` <> 1)
union
select `dz5`.`f`.`target_user_id` AS `target_user_id`
from `dz5`.`friends_requests_for_id_1_view` `f`
where (`dz5`.`f`.`target_user_id` <> 1)
order by `f_ids`;

