create definer = root@localhost view friends_of_friends as
select `f`.`initiator_user_id` AS `initiator_user_id`, `f`.`target_user_id` AS `target_user_id`
from `dz5`.`friend_requests` `f`
where ((`f`.`status` = 'approved') and (`f`.`initiator_user_id` <> 1) and (`f`.`target_user_id` <> 1) and
       (`f`.`initiator_user_id` in (select `dz5`.`friends_1_ids`.`f_ids` from `dz5`.`friends_1_ids`) or
        `f`.`target_user_id` in (select `dz5`.`friends_1_ids`.`f_ids` from `dz5`.`friends_1_ids`)));

