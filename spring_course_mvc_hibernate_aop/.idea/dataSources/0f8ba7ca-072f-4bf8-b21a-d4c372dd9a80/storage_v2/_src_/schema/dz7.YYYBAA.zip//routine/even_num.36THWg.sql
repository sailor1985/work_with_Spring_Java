create
    definer = root@localhost procedure even_num(IN num int)
BEGIN
DECLARE result VARCHAR(100);
DECLARE step INT;
SET step = 0;
SET result = '';
	WHILE step < num - 1 DO
		SET step = step + 2;
		IF step = 2 THEN
		SET result = step;
	ELSE
		SET result = CONCAT(result, ', ', step);
		END IF;
	END WHILE;
SELECT result AS Even_numbers;
END;

