create definer = root@localhost view copyproducts as
select `myfirstdb`.`products_phones`.`PRICE`        AS `Price`,
       `myfirstdb`.`products_phones`.`ProductCount` AS `ProductCount`,
       `myfirstdb`.`products_phones`.`Manufacturer` AS `Manufacturer`,
       `myfirstdb`.`products_phones`.`ProductName`  AS `ProductName`
from `myfirstdb`.`products_phones`
where (`myfirstdb`.`products_phones`.`Manufacturer` = 'Apple');

